package com.spring_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieSwipeApplicationTests {

	@Test
	void contextLoads() {
	}

}
