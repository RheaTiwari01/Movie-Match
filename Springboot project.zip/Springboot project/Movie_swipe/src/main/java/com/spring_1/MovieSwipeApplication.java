package com.spring_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieSwipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieSwipeApplication.class, args);
	}

}
