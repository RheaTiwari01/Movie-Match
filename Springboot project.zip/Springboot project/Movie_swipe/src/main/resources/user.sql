create table user(
id int AUTO_INCREMENT primary key, username varchar(250) unique NOT NULL, password varchar(250) NOT NULL);
